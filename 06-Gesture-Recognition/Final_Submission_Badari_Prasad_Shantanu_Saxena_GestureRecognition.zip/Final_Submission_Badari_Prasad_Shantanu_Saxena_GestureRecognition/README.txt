Please note due to size constraints, we had to zip ipynb file and models file dir. This zip file contains

1) Archived ipynb file
2) Write up file with details
3) Archived H5 Models dir. 